import { PremiumBackground } from "@/components/background"
import { FeatureCard } from "@/components/ui/FeatureCard"
import { HeroHeading } from "@/components/ui/HeroHeading"
import { UIButton } from "@/components/ui/UIButton"

export default function Home() {
  return (
    <main className="relative min-h-[100svh] overflow-x-hidden bg-[#070B16] px-4 py-10 md:px-8 md:py-14">
      <PremiumBackground />

      <section className="relative z-10 mx-auto w-full max-w-7xl">
        <div className="mb-10 flex justify-end gap-3">
          <UIButton variant="secondary">Login</UIButton>
          <UIButton variant="primary">Cadastre-se</UIButton>
        </div>

        <HeroHeading
          logoSrc="/barboo-logo-horizontal.png"
          logoAlt="Barboo"
          titleStart="Conectando"
          highlight="barbeiros"
          titleEnd="e clientes."
          subtitle="Tenha controle da sua barbearia ou encontre profissionais e horários com rapidez em uma experiência moderna e intuitiva."
        />

        <div className="mt-10 grid grid-cols-1 gap-5 md:mt-12 md:grid-cols-3 md:gap-6">
          <FeatureCard
            title="Sou Proprietário"
            description="Cadastre-se para gerenciar sua barbearia e atrair mais clientes para o seu negócio."
            iconSrc="/file.png"
            ctaLabel="Saiba mais"
            ctaVariant="secondary"
          />

          <FeatureCard
            title="Sou Cliente"
            description="Agende cortes e encontre a barbearia ideal para você com poucos toques."
            iconSrc="/user.png"
            ctaLabel="Criar Conta"
            ctaVariant="primary"
          />

          <FeatureCard
            title="Encontrar Barbearias"
            description="Busque barbearias próximas e marque seu horário de forma simples e rápida."
            iconSrc="/location.png"
            ctaLabel="Pesquisar"
            ctaVariant="primary"
            floatingIllustrationSrc="/next.svg"
            floatingIllustrationAlt="Barber pole"
          />
        </div>
      </section>
    </main>
  )
}