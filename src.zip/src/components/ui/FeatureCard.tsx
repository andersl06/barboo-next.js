import Image from "next/image";
import { UIButton } from "./UIButton";

type FeatureCardProps = {
  title: string;
  description?: string;
  iconSrc?: string;
  ctaLabel: string;
  ctaVariant: "primary" | "secondary";
  onCtaClick?: () => void;
  floatingIllustrationSrc?: string;
  floatingIllustrationAlt?: string;
};

export function FeatureCard({
  title,
  description,
  iconSrc,
  ctaLabel,
  ctaVariant,
  onCtaClick,
  floatingIllustrationSrc,
  floatingIllustrationAlt = "Ilustração",
}: FeatureCardProps) {
  return (
    <article className="group relative w-full min-h-[320px] overflow-visible rounded-2xl border border-white/10 bg-[linear-gradient(180deg,rgba(19,20,58,0.92)_0%,rgba(14,16,54,0.88)_55%,rgba(20,23,51,0.93)_100%)] p-6 text-[#f1f2f7] shadow-[0_20px_60px_rgba(0,0,0,0.55)] ring-1 ring-white/5 backdrop-blur-md before:pointer-events-none before:absolute before:inset-0 before:rounded-2xl before:bg-[radial-gradient(120%_80%_at_0%_0%,rgba(255,255,255,0.16),transparent_45%)] before:opacity-70 after:pointer-events-none after:absolute after:inset-0 after:rounded-2xl after:bg-[radial-gradient(120%_75%_at_60%_100%,rgba(0,0,0,0.42),transparent_50%)]">
      <div className="pointer-events-none absolute inset-0 rounded-2xl opacity-[0.08] mix-blend-screen [background-image:radial-gradient(rgba(255,255,255,0.8)_0.7px,transparent_0.7px)] [background-size:3px_3px]" />

      <div className="relative z-10 flex h-full flex-col">
        <header className="flex items-center gap-4 border-b border-white/10 pb-4">
          <div className="relative flex h-14 w-14 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-b from-[#ff8a3d] to-[#e85b1f] ring-1 ring-white/10 shadow-[0_0_24px_rgba(243,108,32,0.25)] before:pointer-events-none before:absolute before:inset-0 before:bg-[radial-gradient(70%_55%_at_25%_18%,rgba(255,255,255,0.38),transparent_70%)] after:pointer-events-none after:absolute after:inset-0 after:bg-[linear-gradient(to_top,rgba(0,0,0,0.18),transparent_45%)]">
            {iconSrc ? (
              <Image
                src={iconSrc}
                alt=""
                width={36}
                height={36}
                className="relative z-10 h-8 w-8 object-contain md:h-9 md:w-9"
              />
            ) : (
              <div className="relative z-10 size-8 rounded-md bg-white/30 md:size-9" />
            )}
          </div>

          <h3 className="text-[22px] font-semibold tracking-tight text-[#f1f2f7]">{title}</h3>
        </header>

        <section className="mt-5 space-y-3">
          {description ? (
            <p className="text-[17px] leading-relaxed text-[#8a89a9]">{description}</p>
          ) : (
            <>
              <div className="h-3 rounded-full bg-white/12" />
              <div className="h-3 w-11/12 rounded-full bg-white/10" />
              <div className="h-3 w-8/12 rounded-full bg-white/10" />
            </>
          )}
        </section>

        <footer className="mt-auto pt-6">
          <UIButton variant={ctaVariant} onClick={onCtaClick}>
            {ctaLabel}
          </UIButton>
        </footer>
      </div>

      {floatingIllustrationSrc ? (
        <div className="pointer-events-none absolute -right-8 bottom-0 z-20 hidden md:block">
          <Image
            src={floatingIllustrationSrc}
            alt={floatingIllustrationAlt}
            width={110}
            height={200}
            className="h-auto w-[95px] object-contain drop-shadow-[0_12px_25px_rgba(0,0,0,0.55)]"
          />
        </div>
      ) : null}
    </article>
  );
}
