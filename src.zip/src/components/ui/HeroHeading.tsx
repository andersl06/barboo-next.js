import Image from "next/image";

type HeroHeadingProps = {
  titleStart: string;
  highlight: string;
  titleEnd: string;
  subtitle: string;
  logoSrc?: string;
  logoAlt?: string;
};

export function HeroHeading({
  titleStart,
  highlight,
  titleEnd,
  subtitle,
  logoSrc = "/next.svg",
  logoAlt = "Barboo",
}: HeroHeadingProps) {
  return (
    <div className="mx-auto max-w-4xl text-center">
      <Image
        src={logoSrc}
        alt={logoAlt}
        width={300}
        height={80}
        priority
        className="mx-auto mb-6 w-[200px] max-w-[70vw] h-auto drop-shadow-[0_10px_25px_rgba(0,0,0,0.35)] md:w-[300px]"
      />

      <h1 className="text-balance text-4xl font-extrabold leading-[1.05] tracking-tight text-[#f1f2f7] [text-shadow:0_4px_18px_rgba(0,0,0,0.42)] md:text-5xl lg:text-6xl">
        {titleStart}{" "}
        <span className="text-[#2b67e0] drop-shadow-[0_0_10px_rgba(43,103,224,0.35)]">
          {highlight}
        </span>{" "}
        {titleEnd}
      </h1>

      <p className="mx-auto mt-4 max-w-2xl text-pretty text-base leading-relaxed text-[#8a89a9] md:text-lg">
        {subtitle}
      </p>
    </div>
  );
}
